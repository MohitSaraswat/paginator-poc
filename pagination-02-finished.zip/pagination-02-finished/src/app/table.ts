export class Table {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}