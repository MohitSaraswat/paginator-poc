import { AppService } from './app.service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatSelectChange } from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AppService]
})
export class AppComponent implements OnInit { 

  constructor(private as: AppService) { }

  ngOnInit() {
  }

  states = [
    {code: 'nar', name: 'nar'},
    {code: 'nar1', name: 'nar1'}
  ];

  someMethod(value){
    console.log(value);
    this.as.setMessage(value);
  }

}