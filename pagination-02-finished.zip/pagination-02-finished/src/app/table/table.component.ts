import { AppService } from './../app.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from '../table';
import { Subscription } from 'rxjs';
import {MatPaginator, MatTableDataSource} from '@angular/material';

const ELEMENT_DATA: Table[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];

const ELEMENT_DATA1: Table[] = [
  {position: 1, name: 'Hydrogen1', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium1', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium1', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium1', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron1', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon1', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen1', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen1', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine1', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon1', weight: 20.1797, symbol: 'Ne'},
  {position: 1, name: 'Hydrogen1', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium1', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium1', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium1', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron1', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon1', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen1', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen1', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine1', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon1', weight: 20.1797, symbol: 'Ne'},
];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  message: string;


  dataSource = new MatTableDataSource<any>(ELEMENT_DATA);

  
    @ViewChild(MatPaginator) paginator: MatPaginator;
  
    /**
     * Set the paginator after the view init since this component will
     * be able to query its view for the initialized paginator.
     */
    ngAfterViewInit() {
      this.dataSource.paginator = this.paginator;
    }
  
  constructor(private as: AppService, private ar:ActivatedRoute) {}
   

  ngOnInit() {

    this.as.message.subscribe(
      (message) => {
        this.message = message;
        if(this.message == 'nar') {
          this.dataSource = new MatTableDataSource<any>(ELEMENT_DATA);
          this.dataSource.paginator = this.paginator;
        } else if (this.message == 'nar1') {
          this.dataSource = new MatTableDataSource<any>(ELEMENT_DATA1);
          this.dataSource.paginator = this.paginator;
        }
      }
    );

    if(this.ar.snapshot.routeConfig.path === '' ) {
      this.dataSource = new MatTableDataSource<any>(ELEMENT_DATA);
    } else if (this.ar.snapshot.routeConfig.path === '1') {
      this.dataSource = new MatTableDataSource<any>(ELEMENT_DATA1);
    }

  }

}
